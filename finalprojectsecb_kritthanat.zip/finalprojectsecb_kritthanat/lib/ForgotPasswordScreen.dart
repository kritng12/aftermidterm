import 'package:finalprojectsecb_kritthanat/auth.dart';
import 'package:flutter/material.dart';
import 'auth.dart'; // นำเข้า AuthService ที่คุณสร้างไว้

class ForgotPasswordScreen extends StatelessWidget {
  final TextEditingController emailController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Forget Password')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: emailController,
              decoration: InputDecoration(
                labelText: 'Email',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.emailAddress,
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                final email = emailController.text.trim();
                if (email.isNotEmpty) {
                  AuthService().resetPassword(email, context);
                } else {
                  AuthService().showSnackbar(context, 'กรุณากรอกอีเมล');
                }
              },
              child: Text('รีเซ็ตรหัสผ่าน'),
            ),
          ],
        ),
      ),
    );
  }
}
