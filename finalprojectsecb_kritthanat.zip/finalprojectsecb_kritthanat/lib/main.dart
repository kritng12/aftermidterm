import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'profilesetup.dart';

import 'auth.dart';
import 'signin_page.dart';
import 'home_page.dart';

//Method หลักทีRun
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyAt_DMcrQsHf3909-ArmCwFil6RQRigiQA",
            authDomain: "logintu-f4841.firebaseapp.com",
            databaseURL: "https://logintu-f4841-default-rtdb.firebaseio.com",
            projectId: "logintu-f4841",
            storageBucket: "logintu-f4841.appspot.com",
            messagingSenderId: "825473507417",
            appId: "1:825473507417:web:868a290e3e4e7ae636d148",
            measurementId: "G-EG5H76LEMR"));
  } else {
    await Firebase.initializeApp();
  }
  runApp(MyApp());
}

// Class MyApp ส าหรับการแสดงผลหน้าจอ
class MyApp extends StatelessWidget {
  MyApp({super.key});
// ตรวจสอบ AuthService
  final AuthService _auth = AuthService();
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.blue,
          iconTheme: IconThemeData(color: Colors.white),
          titleTextStyle: TextStyle(color: Colors.white, fontSize: 20.0),
        ),
      ),
      home: StreamBuilder(
        stream: _auth.authStateChanges, // ตรวจสอบการเชื่อมต่อ Stream
        builder: (BuildContext context, AsyncSnapshot<User?> snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasData) {
            return HomePage(); // ตรวจสอบว่ามี HomePage และท างานได้
          } else {
            return const SigninPage(); // ตรวจสอบว่ามี LoginPage และท างานได้
          }
        },
      ),
      routes: {
        Profilesetup.routeName: (BuildContext context) => Profilesetup(),
        SigninPage.routeName: (BuildContext context) => const SigninPage(),
        HomePage.routeName: (BuildContext context) => HomePage(),
      },
    );
  }
}
